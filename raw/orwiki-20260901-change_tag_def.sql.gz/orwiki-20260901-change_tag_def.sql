/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.29-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: dbstore1007.eqiad.wmnet    Database: orwiki
-- ------------------------------------------------------
-- Server version	10.11.13-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `change_tag_def`
--

DROP TABLE IF EXISTS `change_tag_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `change_tag_def` (
  `ctd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctd_name` varbinary(255) NOT NULL,
  `ctd_user_defined` tinyint(1) NOT NULL,
  `ctd_count` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ctd_id`),
  UNIQUE KEY `ctd_name` (`ctd_name`),
  KEY `ctd_count` (`ctd_count`),
  KEY `ctd_user_defined` (`ctd_user_defined`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=binary ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `change_tag_def`
--

/*!40000 ALTER TABLE `change_tag_def` DISABLE KEYS */;
INSERT INTO `change_tag_def` VALUES (1,'mw-new-redirect',0,12389),(2,'mw-blank',0,1404),(3,'mobile edit',0,21000),(4,'mobile web edit',0,16787),(5,'visualeditor',0,29682),(6,'mw-changed-redirect-target',0,3125),(7,'visualeditor-wikitext',0,4653),(8,'mobile app edit',0,4442),(9,'android app edit',0,1781),(10,'visualeditor-switched',0,3653),(12,'OAuth CID: 429',0,17040),(13,'OAuth CID: 651',0,1509),(15,'contenttranslation',0,5834),(16,'emoji',0,111),(17,'massmessage-delivery',0,1686),(18,'meta spam id',0,1),(25,'mw-removed-redirect',0,177),(26,'mw-replace',0,165),(27,'mw-rollback',0,1664),(28,'mw-undo',0,882),(32,'wikilove',0,151),(33,'ios app edit',0,30),(34,'contenttranslation-v2',0,4166),(35,'OAuth CID: 1206',0,1),(36,'blanking',0,2),(38,'OAuth CID: 1261',0,2),(39,'OAuth CID: 1352',0,16),(40,'advanced mobile edit',0,2102),(41,'ଉଇକିପିଡ଼ିଆ:ଗୁଗୁଲ ଟ୍ରାନ୍ସଲେଟ ସାହାଯ୍ୟରେ ଅନୁବାଦ',1,0),(42,'OAuth CID: 1805',0,130),(43,'mw-manual-revert',0,2355),(44,'OAuth CID: 1841',0,5931),(45,'mw-reverted',0,6575),(46,'T144167',0,46),(47,'discussiontools',0,576),(48,'discussiontools-reply',0,163),(49,'discussiontools-visual',0,316),(52,'discussiontools-source',0,260),(53,'discussiontools-source-enhanced',0,260),(54,'disambiguator-link-added',0,272),(55,'discussiontools-added-comment',0,1360),(56,'discussiontools-newtopic',0,413),(57,'newcomer task',0,160),(58,'wikieditor',0,35044),(59,'newcomer task copyedit',0,18),(60,'mw-contentmodelchange',0,4),(61,'sectiontranslation',0,137),(62,'newcomer task references',0,11),(63,'newcomer task links',0,10),(64,'OAuth CID: 3711',0,429),(65,'editcheck-references',0,902),(66,'OAuth CID: 1804',0,54),(67,'OAuth CID: 4664',0,1697),(68,'editcheck-newcontent',0,1142),(69,'editcheck-newreference',0,4004),(70,'newcomer task add link',0,38),(71,'OAuth CID: 5481',0,1),(72,'OAuth CID: 6365',0,99),(73,'OAuth CID: 1703',0,723),(75,'contenttranslation-high-unmodified-mt-text',0,2),(76,'newcomer task update',0,5),(77,'editcheck-references-activated',0,117),(78,'editcheck-reference-decline-other',0,15),(79,'editcheck-reference-decline-common-knowledge',0,36),(80,'community configuration',0,13),(81,'OAuth CID: 8945',0,5),(82,'app-talk-topic',0,16),(83,'app-section-source',0,171),(84,'editcheck-reference-decline-uncertain',0,3),(85,'app-full-source',0,18),(86,'app-select-source',0,13),(87,'OAuth CID: 9394',0,492),(89,'nuke',0,4),(90,'editcheck-reference-decline-irrelevant',0,4),(91,'mw-recreated',0,47),(92,'newcomer task expand',0,76),(93,'editcheck-references-shown',0,45),(94,'app-talk-reply',0,3),(95,'app-talk-source',0,1),(96,'editcheck-paste-shown',0,74),(97,'editsuggestion-seen',0,1),(98,'OAuth CID: 18951',0,2),(99,'OAuth CID: 19107',0,2);
/*!40000 ALTER TABLE `change_tag_def` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-01 12:03:21
